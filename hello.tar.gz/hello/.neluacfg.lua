return require("init") {
    name = "hello",
    version = "3.1.1",
    dependencies = {},
    add_path = { "." }
}
